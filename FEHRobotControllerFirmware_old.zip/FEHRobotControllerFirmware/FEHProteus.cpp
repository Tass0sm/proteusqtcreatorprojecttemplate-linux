#include "FEHProteus.h"

FEHPropeller Propeller;

int CoreClockKHz;
int CoreClockMHz;
int PeripheralClockKHz;


//FEHProteus::FEHProteus()
//{
//}
